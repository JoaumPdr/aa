package br.inatel.dexmarket.service;

import br.inatel.dexmarket.model.Troca;

public class TrocaService {

    public void realizarTroca(Troca troca) {
        System.out.println("Trocando: " + troca);
        // Lógica de validação e troca real virá aqui
    }
}